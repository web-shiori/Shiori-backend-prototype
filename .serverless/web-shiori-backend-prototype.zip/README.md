# Shiori-backend-prototype
web-shioriのバックエンドプロトタイプ

## 使用技術
- Golang
- Serverless Framework
- AWS lambda
- AWS DynamoDB
- AWS CloudFormation
- AWS API Gateway

# 開発
# デプロイ
```
make deploy
```
